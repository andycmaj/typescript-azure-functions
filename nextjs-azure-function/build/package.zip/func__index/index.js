const page = require("./__index.js");

module.exports = async function (context) {
    await page.render(context.bindings.req, context.res);
};